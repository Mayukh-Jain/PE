import pandas as pd
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import joblib
import os

# Load dataset
data = pd.read_csv("PE advance/Data.csv")

# Define features and target
features = ['rainfall', 'temp', 'windspeed', 'humidity']
target = 'FLOOD'

# Train Flood Model
def train_flood_model():
    X = data[features]
    y = data[target]

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    model = RandomForestClassifier(random_state=42)
    model.fit(X_scaled, y)

    return model, scaler

# Train Weather Models
def train_weather_models():
    weather_data = data[features]

    temp_model = RandomForestRegressor(random_state=42)
    humidity_model = RandomForestRegressor(random_state=42)
    windspeed_model = RandomForestRegressor(random_state=42)
    rainfall_model = RandomForestRegressor(random_state=42)

    X = weather_data.dropna()
    y_temp = X['temp']
    y_humidity = X['humidity']
    y_windspeed = X['windspeed']
    y_rainfall = X['rainfall']

    X_train, _, y_temp_train, _ = train_test_split(X, y_temp, test_size=0.2, random_state=42)
    _, _, y_humidity_train, _ = train_test_split(X, y_humidity, test_size=0.2, random_state=42)
    _, _, y_windspeed_train, _ = train_test_split(X, y_windspeed, test_size=0.2, random_state=42)
    _, _, y_rainfall_train, _ = train_test_split(X, y_rainfall, test_size=0.2, random_state=42)

    temp_model.fit(X_train, y_temp_train)
    humidity_model.fit(X_train, y_humidity_train)
    windspeed_model.fit(X_train, y_windspeed_train)
    rainfall_model.fit(X_train, y_rainfall_train)

    return temp_model, humidity_model, windspeed_model, rainfall_model

# Train the models
flood_model, flood_scaler = train_flood_model()
temp_model, humidity_model, windspeed_model, rainfall_model = train_weather_models()

# Save the models
os.makedirs("models", exist_ok=True)

# Save Flood Model and Scaler
joblib.dump((flood_model, flood_scaler), "models/flood_model.pkl")

# Save Weather Prediction Models
joblib.dump((temp_model, humidity_model, windspeed_model, rainfall_model), "models/weather_models.pkl")

print("Models saved successfully.")
