from flask import Flask, request, jsonify, render_template
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
import pandas as pd
import numpy as np
import requests

# Initialize Flask app
app = Flask(__name__)

# Load and preprocess dataset
def train_model():
    # Replace this with your actual dataset path
    dataset = pd.read_csv("Data.csv")
    
    # Extract features and labels
    X = dataset[['temp', 'windspeed', 'humidity']].values
    y = dataset['FLOOD'].values  # Ensure flood_risk is binary: 0 (no flood), 1 (flood)

    # Scale features
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    # Train SVM model
    model = SVC(kernel='linear', probability=True)
    model.fit(X_scaled, y)
    
    return model, scaler

# Train the model on app start
svm_model, scaler = train_model()

# API key for weather data (replace with your actual API key)
API_KEY = "f18acc43e2da39df93a8293f004bea83"

@app.route("/")
def home():
    return render_template("index.html")  # Ensure this file is in the 'templates' folder

@app.route("/weather", methods=["GET"])
def get_weather_and_predict():
    location = request.args.get("location")
    if not location:
        return jsonify({"error": "Please provide a location."}), 400

    # Fetch live weather data
    weather_api_url = f"http://api.openweathermap.org/data/2.5/weather?q={location}&appid={API_KEY}&units=metric"
    response = requests.get(weather_api_url)
    if response.status_code != 200:
        return jsonify({"error": f"Could not fetch weather data for {location}."}), 404

    weather_data = response.json()
    temperature = weather_data["main"]["temp"]
    humidity = weather_data["main"]["humidity"]
    wind_speed = weather_data["wind"]["speed"]

    # Prepare input for SVM model
    input_features = np.array([[temperature, humidity, wind_speed]])
    input_scaled = scaler.transform(input_features)

    # Predict flood risk
    flood_risk_probability = svm_model.predict_proba(input_scaled)[0][1]  # Probability of flood (label 1)
    flood_risk_percentage = round(flood_risk_probability * 100, 2)
    flood_risk = "High" if flood_risk_probability > 0.5 else "Low"

    # Return weather and prediction
    return jsonify({
        "location": location,
        "temperature": temperature,
        "humidity": humidity,
        "wind_speed": wind_speed,
        "flood_risk": flood_risk,
        "flood_risk_percentage": f"{flood_risk_percentage}%"  # Add risk percentage
    })

if __name__ == "__main__":
    app.run(debug=True)
