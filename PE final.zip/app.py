from flask import Flask, request, jsonify, render_template
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import requests
from datetime import datetime, timedelta
import csv
app = Flask(__name__)

# Replace with your Weather API key
WEATHER_API_KEY = "f18acc43e2da39df93a8293f004bea83"
WEATHER_API_URL = "http://api.openweathermap.org/data/2.5/weather"


# Load your dataset (replace 'dataset.csv' with your actual file)
data = pd.read_csv("Pe advance/Data.csv")

# Feature selection for flood prediction
features = ['rainfall', 'temp', 'windspeed', 'humidity']
target = 'FLOOD'  # Replace this with your actual target column

# Feature selection for weather prediction (same features, you can include more if necessary)
weather_features = ['rainfall', 'temp', 'windspeed', 'humidity']

# Train the Random Forest Classifier for flood prediction
def train_flood_model():
    X = data[features]
    y = data[target]
    
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    model = RandomForestClassifier(random_state=42)
    model.fit(X_scaled, y)
    
    return model, scaler


# Train Random Forest Regressor for weather prediction
def train_weather_model():
    weather_data = data[weather_features]
    
    # Predict each weather feature for the next day using RandomForestRegressor
    temp_model = RandomForestRegressor(random_state=42)
    humidity_model = RandomForestRegressor(random_state=42)
    windspeed_model = RandomForestRegressor(random_state=42)
    rainfall_model = RandomForestRegressor(random_state=42)
    
    X = weather_data.dropna()  # Make sure we drop missing values for the regression task
    y_temp = X['temp']
    y_humidity = X['humidity']
    y_windspeed = X['windspeed']
    y_rainfall = X['rainfall']
    
    X_train, _, y_temp_train, _ = train_test_split(X, y_temp, test_size=0.2, random_state=42)
    _, _, y_humidity_train, _ = train_test_split(X, y_humidity, test_size=0.2, random_state=42)
    _, _, y_windspeed_train, _ = train_test_split(X, y_windspeed, test_size=0.2, random_state=42)
    _, _, y_rainfall_train, _ = train_test_split(X, y_rainfall, test_size=0.2, random_state=42)
    
    temp_model.fit(X_train, y_temp_train)
    humidity_model.fit(X_train, y_humidity_train)
    windspeed_model.fit(X_train, y_windspeed_train)
    rainfall_model.fit(X_train, y_rainfall_train)
    
    return temp_model, humidity_model, windspeed_model, rainfall_model

flood_model, flood_scaler = train_flood_model()
temp_model, humidity_model, windspeed_model, rainfall_model = train_weather_model()

@app.route('/')
def home():
    return render_template('index.html')

@app.route("/predict", methods=["POST"])
def predict():
    global data
    try:
        # Get location from user input
        location = request.json.get("location")
        if not location:
            return jsonify({"error": "Location is required"}), 400

        # Fetch current weather data from OpenWeather API
        weather_response = requests.get(WEATHER_API_URL, params={
            "q": location,
            "appid": WEATHER_API_KEY,
            "units": "metric"
        })
        if weather_response.status_code != 200:
            return jsonify({"error": "Failed to fetch weather data"}), 500

        weather_data = weather_response.json()
        current_weather = {
            "temp": weather_data["main"]["temp"],
            "humidity": weather_data["main"]["humidity"],
            "windspeed": weather_data["wind"]["speed"],
            "rainfall": weather_data.get("rain", {}).get("1h", 0)  # Rainfall in last 1 hour
        }

        # Extract last 5 rows from dataset and predict flood risk
        last_5_days = data[features].tail(5)
        current_weather_df = pd.DataFrame([current_weather])
        prediction_input = pd.concat([last_5_days, current_weather_df], ignore_index=True)
        prediction_features = prediction_input[features]

        # Standardize input
        scaled_features = flood_scaler.transform(prediction_features)

        # Predict flood risk
        risk_probabilities = flood_model.predict_proba(scaled_features)
        risk_prediction = flood_model.predict(scaled_features)[-1]  # Latest prediction
        risk_percentage = risk_probabilities[-1][1] * 100  # Probability of "High risk"

        # Correctly format the current weather data for the weather models
        current_weather_values = [current_weather[feature] for feature in features]

        # Predict weather for the next day using the models
        next_day_temp = temp_model.predict([current_weather_values])[0]
        next_day_humidity = humidity_model.predict([current_weather_values])[0]
        next_day_windspeed = windspeed_model.predict([current_weather_values])[0]
        next_day_rainfall = rainfall_model.predict([current_weather_values])[0]

        # Predict flood risk for the next day using the weather prediction
        next_day_weather = {
            "temp": next_day_temp,
            "humidity": next_day_humidity,
            "windspeed": next_day_windspeed,
            "rainfall": next_day_rainfall
        }
        # Format the next day's weather data for flood risk prediction
        next_day_weather_df = pd.DataFrame([next_day_weather])
        next_day_scaled = flood_scaler.transform(next_day_weather_df[features])

        # Predict next day's flood risk
        next_day_risk_probabilities = flood_model.predict_proba(next_day_scaled)
        next_day_risk_prediction = flood_model.predict(next_day_scaled)[0]
        next_day_risk_percentage = next_day_risk_probabilities[0][1] * 100  # Probability of "High risk"

         # Get today's date in dmy format
        today_date = datetime.now().strftime("%Y-%m-%d")

        # Ensure 'datetime' column is in datetime format (if not already done)
        # data['datetime'] = pd.to_datetime(data['datetime'], format='%Y-%m-%d', errors='coerce')
        # value = data.iloc[711]['datetime']
        # Check if conversion to datetime was successful
        # if data['datetime'].isnull().any():
        #     raise ValueError("Some datetime values couldn't be converted to datetime format.")
        
                
        # Check if today's data is already in the dataset
        if not today_date in data['datetime'].values:
            # Append the new weather data to the dataset
            # print(data['datetime'].dt.date,today_date)
            new_row = {
                "datetime": datetime.now().strftime("%Y-%m-%d"),  # Current date and time in dmy format
                "temp": current_weather["temp"],
                "humidity": current_weather["humidity"],
                "windspeed": current_weather["windspeed"],
                "rainfall": current_weather["rainfall"],
                "FLOOD": 0  # Placeholder for flood status, to be updated later
            }
            lst = list(new_row.values())
            with open('PE advance/Data.csv', mode='a', newline='') as file:
                writer = csv.writer(file)
                
                writer.writerow(lst)
            
            # data=pd.concat([data, new_row], ignore_index=True)
            data = pd.read_csv("Pe advance/Data.csv")
            # Save the updated data back to the CSV file
            # data.to_csv("Pe advance/Data.csv", index=False)

        return jsonify({
            "location": location,
            "current_temperature": current_weather["temp"],
            "current_humidity": current_weather["humidity"],
            "current_windspeed": current_weather["windspeed"],
            "current_rainfall": current_weather["rainfall"],
            "current_flood_risk": "High" if risk_prediction == 1 else "Low",
            "current_risk_percentage": f"{risk_percentage:.2f}%",
            "next_day_temperature": next_day_temp,
            "next_day_humidity": next_day_humidity,
            "next_day_windspeed": next_day_windspeed,
            "next_day_rainfall": next_day_rainfall,
            "next_day_flood_risk": "High" if next_day_risk_prediction == 1 else "Low",
            "next_day_risk_percentage": f"{next_day_risk_percentage:.2f}%"
        })

    except Exception as e:
        return jsonify({"error": f"An error occurred: {str(e)}"}), 500

if __name__ == "__main__":
    app.run(debug=True)
